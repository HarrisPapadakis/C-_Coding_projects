#include <iostream>
using namespace std;
//main.cpp
#include "Vehicle.h"

int main()
{
	Vehicle veh1;
	Vehicle veh2;

	veh1.setAll("COACH", 7, 8, 9);
	cout<<"------------------------\n";
	veh1.print();

	veh2.setAll("IRA", 17, 18, 19);
	cout<<"------------------------\n";
	veh2.print();

	system("PAUSE");
	return 0;
}
