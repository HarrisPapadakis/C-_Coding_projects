#ifndef VEHICLE_H
	#define VEHICLE_H
	//Vehicle.h
	#include <string>
	using namespace std;
	
	class Vehicle
	{
		private:
			string id;
			int speed, attack, defense;
			static int count;
	
		public:
			Vehicle(string = "\0", int = 50, int = 40, int = 30);
			~Vehicle();
			
			void setAll(string, int, int, int);
			void setId(string);
			void setSpeed(int);
			void setAttack(int);
			void setDefense(int);
			
			static int getCount();
			string getId() const;
			int getSpeed() const;
			int getAttack() const;
			int getDefense() const;
			
			void print() const;
	};
#endif
